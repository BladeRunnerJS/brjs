caplin.include("caplin.core.testing.FixtureFactory", true);
caplin.include("caplin.presenter.testing.PresenterComponentFixture");

HelloWorldFixtureFactory = function()
{
};

caplin.implement(HelloWorldFixtureFactory, caplin.testing.FixtureFactory);

HelloWorldFixtureFactory.prototype.addFixtures = function(oTestRunner)
{
	var sPresenterXml = '<presenter templateId="emptycorp.example.helloworld.view-template" presentationModel="emptycorp.example.helloworld.HelloWorldPresentationModel"/>';
	var oPresenterComponentFixture = new caplin.presenter.testing.PresenterComponentFixture(sPresenterXml);
	
	oTestRunner.addFixture("helloworld", oPresenterComponentFixture); 
};

HelloWorldFixtureFactory.prototype.resetFixtures = function()
{
};
