caplin.require("caplin.bootstrap.bootstrap");

caplin.require("caplin.framework.sl4b.DummySL4B");

caplin.require("jQuery.jquery");
caplin.require("knockout.knockout");
caplin.require("extjs.ext-caplintrader");
caplin.require("extjs.ext-caplintrader-extensions");

RightClickMenuDecoratorTest = TestCase("RightClickMenuDecoratorTest");

caplin.constructSingletons();

RightClickMenuDecoratorTest.prototype.testInstantiation = function()
{
    new emptycorp.example.grid.RightClickMenuDecorator({});
};
