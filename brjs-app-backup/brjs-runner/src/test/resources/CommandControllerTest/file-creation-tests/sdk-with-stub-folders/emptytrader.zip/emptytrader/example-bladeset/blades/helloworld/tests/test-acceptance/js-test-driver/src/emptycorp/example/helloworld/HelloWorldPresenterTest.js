caplin.require("caplin.bootstrap.bootstrap");
caplin.require("caplin.framework.sl4b.DummySL4B");
caplin.require("jQuery.jquery");
caplin.require("knockout.knockout");
caplin.require("extjs.ext-caplintrader");
caplin.require("extjs.ext-caplintrader-extensions");

caplin.require("caplin.testing.GwtTestRunner");
caplin.require("caplin.presenter.component.PresenterComponentFactory");

describe("Hello world blade", function()
{
	fixtures("HelloWorldFixtureFactory");
	
	caplin.onLoad();
	
	caplin.services.HTMLResourceService.loadFromBundler = false;
	caplin.services.HTMLResourceService.loadHTMLFiles(["/test/tests/test-acceptance/js-test-driver/bundles/html.bundle"]);
	
	it("says hello", function() {
		given("helloworld.opened = true");
		then("helloworld.model.message = 'Hello World from Presenter Blade!'");
	});
	 
});