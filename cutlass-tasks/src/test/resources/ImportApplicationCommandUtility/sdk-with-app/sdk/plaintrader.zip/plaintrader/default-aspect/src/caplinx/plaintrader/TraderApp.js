caplinx.plaintrader.TraderApp = function()
{

};

