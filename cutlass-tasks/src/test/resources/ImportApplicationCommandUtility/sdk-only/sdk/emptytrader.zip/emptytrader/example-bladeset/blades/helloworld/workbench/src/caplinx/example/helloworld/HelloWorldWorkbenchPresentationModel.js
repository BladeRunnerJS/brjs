caplinx.example.helloworld.HelloWorldWorkbenchPresentationModel = function()
{
	this.message = new caplin.presenter.property.Property( ct.i18n("caplinx.example.helloworld.i18n.hello") + " World from Presenter Blade's workbench!" );
};
caplin.implement(caplinx.example.helloworld.HelloWorldWorkbenchPresentationModel, caplin.presenter.PresentationModel);
