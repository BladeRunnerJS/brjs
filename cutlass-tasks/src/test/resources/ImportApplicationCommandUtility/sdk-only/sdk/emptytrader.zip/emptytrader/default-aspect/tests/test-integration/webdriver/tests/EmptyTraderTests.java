import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.caplin.cutlass.testIntegration.WebDriverProvider;

@RunWith(BlockJUnit4ClassRunner.class)
public class EmptyTraderTests
{
	
	private static WebDriver driver;
	private static String baseUrl;
	
	@BeforeClass
	public static void setupClass() throws Exception
	{
		driver = WebDriverProvider.getDriver(FirefoxDriver.class, new HashMap<String, String>());
		
		baseUrl = WebDriverProvider.getBaseUrl("/emptytrader");

		//TODO: this wont be needed when we are using SL4Bv5
		if (baseUrl.contains("localhost") && !baseUrl.contains(".caplin.com"))
		{
			baseUrl = baseUrl.replace("localhost", "localhost.caplin.com");
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	@AfterClass
	public static void tearDownClass()
	{ 	
		WebDriverProvider.closeDriver(driver);
	}
	
	
	@Test
	public void testEnglishAppLoads() throws Exception
	{
		doLogin("English");
		
		assertPageTitleIs("EmptyTrader");

		WebElement helloWorldDiv = driver.findElement(By.className("hello-world-message"));
		assertTrue(helloWorldDiv.getText().contains("Hello World"));
	}
	
	@Ignore		//TODO: theres a bug when running in Tomcat which means this test fails
	@Test
	public void testGermanAppLoads() throws Exception
	{
		doLogin("German");
		
		assertPageTitleIs("EmptyTrader");
		
		WebElement helloWorldDiv = driver.findElement(By.className("hello-world-message"));
		assertTrue(helloWorldDiv.getText().contains("Guten Tag World"));
	}
	
	

	
	private void doLogin(String locale) throws InterruptedException 
	{		
		driver.manage().deleteAllCookies();
		driver.get(baseUrl + "/?noshutdownwarning");
		
		assertPageTitleIs("Login");
		
		driver.findElement(By.name("j_username")).clear();
		driver.findElement(By.name("j_username")).sendKeys("user1@caplin.com");
		driver.findElement(By.name("j_password")).clear();
		driver.findElement(By.name("j_password")).sendKeys("password");

		WebElement locales = driver.findElement(By.name("locale"));
		List<WebElement> localeOptions = locales.findElements(By.tagName("option"));
		for (WebElement option : localeOptions)
		{
			if (option.getText().equals(locale))
			{
				option.click();
				break;
			}
		}
		driver.findElement(By.name("submit")).click();
	}

	private void assertPageTitleIs(String title) throws InterruptedException
	{
		for (int i = 0; i < 5; i++) 
		{
			if (!driver.getTitle().equals(""))
			{
				break;
			}
			Thread.sleep(1000);
		}
		assertEquals(title, driver.getTitle());
	}
	

}