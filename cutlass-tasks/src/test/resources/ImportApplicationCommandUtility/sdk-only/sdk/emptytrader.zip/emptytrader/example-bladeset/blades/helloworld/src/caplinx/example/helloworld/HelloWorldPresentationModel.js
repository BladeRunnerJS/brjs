caplinx.example.helloworld.HelloWorldPresentationModel = function()
{
	this.message = new caplin.presenter.property.Property( ct.i18n("caplinx.example.helloworld.i18n.hello") + " World from Presenter Blade!" );
};
caplin.implement(caplinx.example.helloworld.HelloWorldPresentationModel, caplin.presenter.PresentationModel);
