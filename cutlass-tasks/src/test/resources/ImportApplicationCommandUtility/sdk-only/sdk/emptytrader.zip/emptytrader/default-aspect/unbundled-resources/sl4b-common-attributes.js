var oConfiguration = SL4B_Accessor.getConfiguration();
oConfiguration.setStreamingConnectionMethods(SL4B_Browser.CHROME, [SL4B_ConnectionMethod.WEBSOCKET]);
oConfiguration.setAttribute("disablepolling", true);