caplin.testing.GwtTestRunner.initialize();
//caplin.presenter.component.PresenterComponentFactory

describe("Hello world blade", function()
{
	fixtures("HelloWorldFixtureFactory");

	it("says hello", function() {
		given("helloworld.opened = true");
		then("helloworld.model.message = 'Hello World from Presenter Blade!'");
	});
	 
});