
caplin.thirdparty("jQuery");
caplin.thirdparty("knockout");
caplin.thirdparty("extjs");

// Currently the classes below have to be defined as string literals to be picked up by ClassProcessor.
// They are referenced only in webcentric layouts.
"caplin.grid.GridGenerator";
"caplinx.example.helloworld.HelloWorldPresentationModel";
"caplinx.example.grid.FX.Major";
caplinx.emptytrader.TraderApp = function()
{

};

caplinx.emptytrader.TraderApp.prototype.initWebcentric = function(event)
{
	// needed by webcentric. 
	this.initialiseFactories();
	
	caplin.widget = {};
	caplin.widget.events = {};
	caplin.widget.events.GlobalEventManager = {};
	caplin.widget.events.GlobalEventManager.raiseEvent = function()
	{
		
	};
	
	//caplin.core.ApplicationProperties.setProperty("CAPLIN.WEBCENTRIC.START.PAGE", "application_layout");
	window.webcentricParams = {theme_path:"unbundled-resources/webcentric/", theme:"blue", layout_theme:"blue", layout_url: "application_layout"};
	
	caplin.onLoad(); //ServiceRegistry is a singleton, "One Ring to bring them all, And in the darkness bind them."
	this._registerServices();
	caplin.framework.WebcentricAdapter.init(event);
}

/** @private */
caplinx.emptytrader.TraderApp.prototype._registerServices = function()
{	
	var oHTMLResourceService = new caplin.services.providers.CaplinHTMLResourceService()
	caplin.core.ServiceRegistry.registerService("caplin.services.HTMLResourceService", oHTMLResourceService);
	
	var oXMLResourceService = new caplin.services.providers.XMLResourceServiceProvider("xml.bundle");
	caplin.core.ServiceRegistry.registerService("caplin.services.XMLResourceService", oXMLResourceService);
}


caplinx.emptytrader.TraderApp.prototype.initialiseFactories = function()
{
	var oTranslator = caplin.i18n.getTranslator()
	oTranslator.getLocale = function() 
	{
		return "en";
	};
	
	var fFactory = function() 
	{
		
	};
	
	fFactory.prototype =
	{
		getInstance: function() {},
		setInstance: function() {},
		getAlertDispatcher: function() {}
	};
	
	caplin.extend(fFactory, caplin.framework.ApplicationFactory);
	caplin.extend(fFactory, caplin.component.AbstractFactory);
	caplin.extend(fFactory, caplin.framework.AbstractFactory);
	caplin.extend(fFactory, caplin.grid.AbstractFactory);
	caplin.extend(fFactory, caplin.security.AbstractFactory);
	caplin.extend(fFactory, caplin.services.AbstractFactory);
	caplin.extend(fFactory, caplin.trading.AbstractFactory);
	caplin.extend(fFactory, caplin.core.AbstractFactory);
};