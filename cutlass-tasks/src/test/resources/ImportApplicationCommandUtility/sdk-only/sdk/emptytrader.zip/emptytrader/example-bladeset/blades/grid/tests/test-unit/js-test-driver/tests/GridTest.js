AlertsMonitorTest = TestCase("GridTest");

AlertsMonitorTest.prototype.setUp = function() {

};

AlertsMonitorTest.prototype.tearDown = function(){
 
};

AlertsMonitorTest.prototype.testTest = function() {
	assertEquals(true, true);
};