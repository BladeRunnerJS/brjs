
HelloWorldFixtureFactory = function()
{
	caplin.onLoad();
	var oHTMLResourceService = new caplin.services.providers.CaplinHTMLResourceService()
	caplin.core.ServiceRegistry.registerService("caplin.services.HTMLResourceService", oHTMLResourceService);
	
	var oXMLResourceService = new caplin.services.providers.XMLResourceServiceProvider("xml.bundle");
	caplin.core.ServiceRegistry.registerService("caplin.services.XMLResourceService", oXMLResourceService);
};

caplin.implement(HelloWorldFixtureFactory, caplin.testing.FixtureFactory);

HelloWorldFixtureFactory.prototype.addFixtures = function(oTestRunner)
{
	var oPresenterComponentFixture = new caplin.presenter.testing.PresenterComponentFixture("caplinx.example.helloworld.view-template", "caplinx.example.helloworld.HelloWorldPresentationModel");
	
	oTestRunner.addFixture("helloworld", oPresenterComponentFixture); 
};

HelloWorldFixtureFactory.prototype.resetFixtures = function()
{
};
